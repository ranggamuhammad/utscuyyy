package com.yasinkacmaz.jetflix.ui.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class JetflixApplication : Application()
