package com.yasinkacmaz.jetflix.ui.moviedetail.image

data class Image(val url: String, val voteCount: Int)
